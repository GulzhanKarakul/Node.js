import express from "express";
import path from "path"

const app = express();
const __dir = process.cwd();


app.get("/", (request, response) => {
    response.end(`<h1>This is Express!</h1>`);
});

app.get("/about", (request, response) => {
    let filename = path.join(__dir, "index.html")
    response.sendFile(filename);
});

app.listen(3000, ()=>{
    console.log("Сервер запущен, порт 3000");
});

app.use( express.static("public") );