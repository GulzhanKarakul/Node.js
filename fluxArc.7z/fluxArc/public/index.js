import action from 'action.js'

let incrBtn = document.getElementById('incr');
let decrBtn = document.getElementById('decr');

